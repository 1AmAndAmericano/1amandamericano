drop table if exists Customers;
drop table if exists Managers;
drop table if exists Reservations;
drop table if exists Rooms;

CREATE TABLE Customers (
	Email 		varchar[20]	PRIMARY KEY NOT NULL,
	Name		varchar[20] NOT NULL,
	Password	varchar[20] NOT NULL
);

CREATE TABLE Managers (
	Email 		varchar[20]	PRIMARY KEY NOT NULL,
	Name		varchar[20] NOT NULL,
	Password	varchar[20] NOT NULL
);

CREATE TABLE Reservations (
	ResvID 			integer 	PRIMARY KEY NOT NULL,
	Email 			varchar[20],
	RoomNumber		integer,
	CheckinDate		TIMESTAMP,
	CheckoutDate	TIMESTAMP,
	Is_Customer		boolean,
	ResvState		integer,
	Price			float,
	Bank			varchar[20]	NOT NULL,
	Account			integer,
	FOREIGN KEY (Email) REFERENCES Customers(Email),
	FOREIGN KEY (RoomNumber) REFERENCES Rooms(RoomNumber)
);

CREATE TABLE Reservations_History (
	ResvID 			integer 	PRIMARY KEY NOT NULL,
	Email 			varchar[20],
	RoomNumber		integer,
	CheckinDate		TIMESTAMP,
	CheckoutDate	TIMESTAMP,
	Is_Customer		boolean,
	ResvState		integer,
	Price			float,
	Bank			varchar[20]	NOT NULL,
	Account			integer,
	FOREIGN KEY (Email) REFERENCES Customers(Email),
	FOREIGN KEY (RoomNumber) REFERENCES Rooms(RoomNumber)
);

CREATE TABLE Rooms (
	RoomNumber		integer 	KEY NOT NULL,
	RoomType		varchar[20],
	RoomPrice		float
);
